function selector(name){
    return document.querySelector(name);
}

const colorBtn = selector('button#color');
const copy = selector('button#pick');
const memoryBox = selector('#memory-box');
let clipBoard = selector('#username');
const saveBtn = selector('#save')

class LinearPicker{
    constructor(screen, memory) {
        this.screen = screen;
        this.memory = memory;
        this.firstColor = '';
        this.secondColor = '';
    }

    formColor(){
        const list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f'];
        let random =  list[Math.floor(Math.random() * 16)];
        let random1 = list[Math.floor(Math.random() * 16)];
        let random2 = list[Math.floor(Math.random() * 16)];
        let random3 = list[Math.floor(Math.random() * 16)];
        let random4 = list[Math.floor(Math.random() * 16)];
        let random5 = list[Math.floor(Math.random() * 16)];
        let random6 = list[Math.floor(Math.random() * 16)];
        let random7 = list[Math.floor(Math.random() * 16)];
        let random8 = list[Math.floor(Math.random() * 16)];
        let random9 = list[Math.floor(Math.random() * 16)];
        let random10 = list[Math.floor(Math.random() * 16)];
        let random11 = list[Math.floor(Math.random() * 16)];

        this.firstColor = `#${random}${random1}${random2}${random3}${random4}${random5}`;
        this.secondColor = `#${random6}${random7}${random8}${random9}${random10}${random11}`;
    }

    addToScreen(){
        const body = document.body;
        body.style.background = `linear-gradient(to right,${this.firstColor},${this.secondColor})`;
        clipBoard.value = `${this.firstColor}, ${this.secondColor}`;
    }

    copy(){
        this.screen.select();
        this.screen.setSelectionRange(1000, 9999);
        document.execCommand('copy');

        window.alert('copied');
    }

    save(){
        if(this.firstColor === '' && this.secondColor === ''){
        alert("can't save the default color");
        }
        else{
            const p = document.createElement('p');
            const s = document.createElement('span');
            const div = document.createElement('div');
            const span = document.createElement('div');

            s.style.display = 'block';
            s.style.fontSize = '13px';
            s.style.width = '50%';
            s.style.fontWeight = 'bold';
            s.style.paddingLeft = '12px';
            s.innerHTML = `${this.firstColor}, ${this.secondColor}`;

            span.style.borderRadius = '3px';
            span.style.padding= '8px 10px';
            span.style.background = `linear-gradient(to right,${this.firstColor},${this.secondColor})`;

            div.style.display = 'block';
            div.style.width = '50%';
            div.style.textAlign = 'center';
            div.appendChild(span);

            p.style.padding = "8px 0px 8px 6px";
            p.style.display = 'flex';
            p.style.justifyContent = 'center';
            p.style.alignItems = 'center';
            p.append(div, s);

            this.memory.append(p);
            document.querySelector('.wrapper').classList.add('add-mem');

            window.alert('added');


        }
    }
}

const linearGradient = new LinearPicker(clipBoard, memoryBox);

colorBtn.addEventListener('click', ()=>{
    linearGradient.formColor();
    linearGradient.addToScreen();
})


copy.addEventListener('click', ()=>{
    linearGradient.copy();
})

saveBtn.addEventListener('click', ()=>{
    linearGradient.save();
})