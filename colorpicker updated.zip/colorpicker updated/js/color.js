function selector(name){
    return document.querySelector(name);
}

const colorBtn = selector('button#color');
const copy = selector('button#pick');
let clipBoard = selector('#username');
const memoryBox = selector('#memory-box');
const saveBtn = selector('#save');

class ColorPicker{
    constructor(screen, memoryScreen) {
        this.screen = screen
        this.memory = memoryScreen
        this.color = '';
    }

    formColor(){
        const list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f']
        let random = list[Math.floor(Math.random() * 16)]
        let random1 = list[Math.floor(Math.random() * 16)]
        let random2 = list[Math.floor(Math.random() * 16)]
        let random3 = list[Math.floor(Math.random() * 16)]
        let random4 = list[Math.floor(Math.random() * 16)]
        let random5 = list[Math.floor(Math.random() * 16)]

        this.color = `#${random}${random1}${random2}${random3}${random4}${random5}`;

    }

    copy(){
        this.screen.select();
        this.screen.setSelectionRange(0, 999999);

        document.execCommand('copy');
        window.alert('copied');
    }

    AddToScreen(){
        const body = document.body;
        body.style.backgroundColor = this.color;
        this.screen.value = this.color;
    }

    saveToMemory(){
        if(this.color == ''){
            alert("can't save the default color");
        }
        else{
            const p = document.createElement('p');
            const s = document.createElement('span');
            const div = document.createElement('div');
            const span = document.createElement('div');

            s.style.display = 'block';
            s.style.fontSize = '18px';
            s.style.width = '50%';
            s.style.fontWeight = 'bold';
            s.style.paddingLeft = '12px';
            s.innerHTML = this.color;

            span.style.borderRadius = '3px';
            span.style.padding= '8px 10px';
            span.style.backgroundColor = s.innerHTML;

            div.style.display = 'block';
            div.style.width = '50%';
            div.style.textAlign = 'center';
            div.appendChild(span);

            p.style.padding = "8px 0px 8px 6px";
            p.style.display = 'flex';
            p.style.justifyContent = 'center';
            p.style.alignItems = 'center';
            p.append(div, s);

            this.memory.append(p);
            document.querySelector('.wrapper').classList.add('add-mem');

            window.alert('added');


        }

    }
}

const colorPicker = new ColorPicker(clipBoard, memoryBox);

colorBtn.addEventListener('click', ()=>{
    colorPicker.formColor();
    colorPicker.AddToScreen();
})

copy.addEventListener('click', ()=>{
    colorPicker.copy();
})

saveBtn.addEventListener('click', ()=>{
    colorPicker.saveToMemory();
})